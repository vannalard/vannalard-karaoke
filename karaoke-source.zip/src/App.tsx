// React Karaoke App Component
